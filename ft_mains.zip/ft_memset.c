/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_memset.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: yeparra- <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/09/18 14:35:30 by yeparra-          #+#    #+#             */
/*   Updated: 2023/10/10 20:02:29 by yeparra-         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

void	*ft_memset(void *s, int c, size_t n)
{
	size_t			i;
	unsigned char	*p;

	p = s;
	i = 0;
	while (n > 0)
	{
		*p = c;
		p++;
		n--;
	}
	return (s);
}
/*
int	main()
{
	unsigned char	*s = "Hola, Mundo";
	unsigned char	*result;

	printf("String original: %s\n", s);
	result = ft_memset(s, 'X', 5);
	priintf("String modificada: %s\n", result);

	return (0);
}*/
